#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 14 12:39:24 2023

@author: dylanmoraes
"""

#program for tables

num = int(input("Enter the number: "))
for i in range(11):
    print(num,"X",i,"=",num*i)